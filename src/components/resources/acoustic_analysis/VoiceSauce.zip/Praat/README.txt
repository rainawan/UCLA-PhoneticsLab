Install Praat

% --------------------------------
% Mac Users
% --------------------------------

1. Visit the link below and download an appropriate version of Praat for your MacOS version
	http://www.fon.hum.uva.nl/praat/download_mac.html
	
2. Double-click the dmg file to mount Praat.

3. Copy the Praat.app file to VoiceSauce/Praat folder.

4. You are ready to use Praat on VoiceSauce


% --------------------------------
% Windows Users
% --------------------------------

1. Visit the link below and download an appropriate version of Praat for your Windows version
	http://www.fon.hum.uva.nl/praat/download_win.html
	
2. Unzip the zip file.

3. Copy the Praat.exe to VoiceSauce/Praat folder.

4. You are ready to use Praat on VoiceSauce
